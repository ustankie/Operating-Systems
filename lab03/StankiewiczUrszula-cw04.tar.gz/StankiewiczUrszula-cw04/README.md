W celu kompilacji odpowiednich podpunktów należy postępować następująco:
- make zad1 kompiluje zadanie 1 
- make zad2 kompiluje zadanie 2
- make all kompiluje wszystkie zadania
  
Testowanie rozwiązań: 
zad1: Uruchamiamy ./build/zad1 arg1 
    gdzie arg1 to liczba procesów do utworzenia

zad2: Uruchamiamy ./build/zad2 arg1
    gdzie arg1 to lokalizacja folderu
