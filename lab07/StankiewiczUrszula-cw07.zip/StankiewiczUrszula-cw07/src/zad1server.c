#include <stdio.h>
#include <stdlib.h>
#include <mqueue.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include <signal.h>

#define BUFF_SIZE 2048
#define MAX_CLIENTS 4
#define PRIORITY 2
#define INIT "INIT"
#define END "END"
#define SERVER "/server"

struct QData{
    char charData[BUFF_SIZE];
    char queue_id[BUFF_SIZE];
    int id_in_server;
    
} ;

mqd_t server;
mqd_t clients[MAX_CLIENTS];

void handle(int signum){
    
    struct QData send_data;
    strcpy(send_data.charData,END);

    printf("Exiting...\n");

    for(int i=0;i<MAX_CLIENTS;i++){
        if(clients[i]){
            
            if(mq_send(clients[i],(char *)&send_data, sizeof(send_data),10)<0){
                    perror("mq_send");
                }
            mq_close(clients[i]);
        }
    }
    mq_close(server);
    mq_unlink(SERVER);
    exit(0);
}

int main()
{   

    struct mq_attr attr;
    attr.mq_flags=0;
    attr.mq_maxmsg=10;
    attr.mq_msgsize=sizeof(struct QData);
    server=mq_open(SERVER,O_RDWR|O_CREAT, S_IRUSR|S_IWUSR, &attr);

    if(server<0){
        perror("mq_open");
        return 0;
    }

    char clients_names[MAX_CLIENTS][BUFF_SIZE];
    
    for(int i=0;i<MAX_CLIENTS;i++){
        clients[i]=NULL;
    }
    

    char buff[BUFF_SIZE];
    int a=0;
    int i=0;
    int client_num=0;
    int j=0;

    signal(SIGINT, handle);
    struct QData message;

    while(1){

        memset(&message, 0, sizeof(struct QData));
        if((a=mq_receive(server,(char *)&message,sizeof(struct QData),NULL))<0){
                perror("mq_receive");
                return -1;
            }
        

        
        if(strcmp(message.charData,INIT)==0){
            printf("INIT! Hello %s, your server id is %d\n",message.queue_id, i);
            if(client_num<MAX_CLIENTS){
                client_num+=1;
                mqd_t new_client=mq_open(message.queue_id,O_RDWR,S_IRUSR|S_IWUSR,NULL);

                while(clients[i]!=NULL){
                    i=(i+1)%MAX_CLIENTS;
                }

                clients[i]=new_client;
                strcpy(clients_names[i],message.queue_id);

                struct QData send_message;
                // memset(&send_message, 0, sizeof(struct QData));
                send_message.id_in_server=i;
                strcpy(send_message.charData,"Welcome to our server!");


                if(mq_send(clients[i],(char *)&send_message, sizeof(send_message),10)<0){
                    perror("mq_send");
                }

                memset(&send_message,0,sizeof(struct QData));
            }
            

        }else if(strcmp(message.charData,END)==0){
            
            if(clients[message.id_in_server]){
                printf("Bye %s!\n",clients_names[message.id_in_server]);
                mq_close(clients[message.id_in_server]);}
            clients[message.id_in_server]=NULL;
            
        }else{
            printf("Message from: %s whose server_id is: %d, Text: %s\n",clients_names[message.id_in_server], message.id_in_server,message.charData);
            strcpy(message.queue_id,clients_names[message.id_in_server]);
            for(int j=0;j<MAX_CLIENTS;j++){
                if(clients[j] && j!=message.id_in_server){
                    if(mq_send(clients[j],(char *)&message, sizeof(message),10)<0){
                        perror("mq_send");
                    }
                }
            }
            
        }
        
    }
   



    
}