
#include <stdio.h>
#include <mqueue.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <stdbool.h>
#include <signal.h>


#define BUFF_SIZE 2048
#define PRIORITY 2
#define INIT "INIT"
#define SERVER "/server"
#define END "END"

struct QData{
    char charData[BUFF_SIZE];
    char queue_id[BUFF_SIZE];
    
    int id_in_server;
    
} ;

mqd_t server;
mqd_t mq;
int id=-1;
char q_name[BUFF_SIZE];


void handle(int signum){
    struct QData send_data;
    strcpy(send_data.charData,END);
    send_data.id_in_server=id;
    mq_unlink(q_name);
    mq_close(mq);
    if(mq_send(server,(char *)&send_data,sizeof(send_data),PRIORITY)==-1){
            perror("mqsend");
            exit(-1);
        }
    mq_close(server);   
    printf("Exiting...\n");

    exit(0);

}

int main()
{   
    
    char buff[BUFF_SIZE];

    struct mq_attr attr;
    attr.mq_flags=0;
    attr.mq_maxmsg=10;
    attr.mq_msgsize=sizeof(struct QData);
    

    sprintf(q_name,"/%d",getpid());

    mq=mq_open(q_name,O_CREAT|O_RDWR,S_IRUSR|S_IWUSR,&attr);

    if(mq<0){
        perror("mq_open");
        return -1;
    }
    for (int sig = 1; sig < SIGRTMAX; sig++) {
        signal(sig, handle);
    }

    struct QData send_data;
    memset(&send_data, 0, sizeof(struct QData));
    send_data.id_in_server=1;
     
    memcpy((send_data.queue_id), q_name,strlen(q_name)); 
    memcpy((send_data.charData), INIT,strlen(INIT));
    

    server=mq_open(SERVER,O_RDWR,S_IRUSR|S_IWUSR,NULL);
    if(server<0){
        perror("mq_open");
        mq_close(mq);
        return -1;
    }

    int a;

    if((a=mq_send(server,(char *)&send_data, sizeof(send_data),10))<0){
        perror("mq_send");
        return -1;
    }
    
    if(mq_receive(mq,(char *)&send_data,sizeof(send_data),NULL)<0){
        perror("mq_receive");
        return -1;
    }
    printf("%s\nYour server_id: %d\n",send_data.charData, send_data.id_in_server);

    id=send_data.id_in_server;
    int i=0;
    pid_t ppid=getpid();

    pid_t child=fork();
    if(child==0){
        while(1)
        {   
            struct QData rec_data;
            if(mq_receive(mq,(char *)&rec_data,sizeof(struct QData),NULL)==-1){
                perror("mq_receive");
                return -1;
            }


            printf("\n\nReceived message: %s \n From: %s whose server_id is: %d\n\nType message: ",rec_data.charData,rec_data.queue_id,rec_data.id_in_server);
            fflush(stdout);

            if(strcmp(rec_data.charData,END)==0){
                kill(ppid,SIGTERM);
                kill(getpid(),SIGTERM);
            }
        }

    }else{
        while(1){
            memset(buff, 0, sizeof(buff));
            printf("Type message: ");
            int n=scanf("%s",&buff);
            
            if(n>0){
                memset(&send_data, 0, sizeof(struct QData));
                send_data.id_in_server=id;
                memcpy((send_data.charData), buff,strlen(buff));

                

                if(mq_send(server,(char *)&send_data,sizeof(send_data),10)==-1){
                    perror("mqsend");
                    return -1;
                }

            }
        }
    }

}