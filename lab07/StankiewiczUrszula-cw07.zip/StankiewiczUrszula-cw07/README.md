W celu kompilacji odpowiednich podpunktów należy postępować następująco:
- make zad1 kompiluje zadanie 1 

Testowanie rozwiązań: 
zad1: Uruchamiamy ./build/zad1server, a następnie w kilku terminalach ./build/zad1client. Następnie serwer powita wszystkich nowych klientów i wyśle do nich wiadomość "Welcome to our server", która zostanie wyświetlona na stdout. Następnie klienci mogą wysłać do siebie wiadomości. Serwer odsyła wiadomości do wszystkich klientów z wyjątkiem tego, który wiadomość wysłał. Wiadomości te są wyświetlane w konsoli klientów. 

